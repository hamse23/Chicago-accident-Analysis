import csv

# Function to read CSV file into a list of dictionaries
def read_csv(file_path):
    with open(file_path, mode='r') as file:
        reader = csv.DictReader(file)
        return [row for row in reader]

# Function to merge two datasets on a given key
def merge_datasets(left, right, key, suffix_left="", suffix_right="", left_join=False):
    merged = []
    right_lookup = {row[key]: row for row in right}
    for left_row in left:
        left_key = left_row[key]
        right_row = right_lookup.get(left_key)
        if right_row or not left_join:
            merged_row = {**left_row}
            if right_row:
                for k, v in right_row.items():
                    if k not in merged_row or k == key:
                        merged_row[k] = v
                    else:
                        merged_row[f"{k}{suffix_right}"] = v
            merged.append(merged_row)
    return merged

# Read data from files
people = read_csv('People_cleaned.csv')  # Replace with your actual file path
vehicle = read_csv('Vehicle_cleaned.csv')  # Replace with your actual file path
crash = read_csv('Crash_cleaned.csv')  # Replace with your actual file path

# Merge people and vehicle datasets on VEHICLE_ID
people_vehicle_merged = merge_datasets(people, vehicle, key="VEHICLE_ID", suffix_left="_person", suffix_right="_vehicle", left_join=True)

# Merge the result with crash dataset on RD_NO
final_merged = merge_datasets(people_vehicle_merged, crash, key="RD_NO", suffix_left="_people_vehicle", left_join=True)

# Write the final merged data to a new file
output_file = 'final_merged.csv'
with open(output_file, mode='w', newline='') as file:
    if final_merged:
        writer = csv.DictWriter(file, fieldnames=final_merged[0].keys())
        writer.writeheader()
        writer.writerows(final_merged)

print(f"Final merged data saved to {output_file}")
